"use client";
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import Logo from "@/public/logo.jpg";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <section className="text-center py-16 px-4">
        <div className="mb-6">
          <Image src={Logo} alt="Logo" width={80} height={80} className="mx-auto rounded-full object-contain" />
        </div>
        <h1 className="text-4xl font-bold mb-4">Elevate Your Brand</h1>
        <p className="text-lg mb-8 max-w-2xl mx-auto text-gray-300">
          We provide top-notch Social Media Management, Video Production, and Photography services to help your brand stand out.
        </p>
        <a href="#contact">
          <Button className="px-6 py-3 text-lg bg-white text-black hover:bg-gray-200">Get a Quote</Button>
        </a>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 px-6 md:px-12 py-10">
        {[
          {
            title: "Social Media Services",
            desc: "Grow your presence with content strategy, management & growth tactics."
          },
          {
            title: "Video Production",
            desc: "Cinematic videos, brand promos, and storytelling that captivates."
          },
          {
            title: "Photography",
            desc: "Professional photoshoots for your brand, events, and products."
          }
        ].map((service, idx) => (
          <Card key={idx} className="rounded-2xl shadow-md bg-neutral-900 text-white">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-400">{service.desc}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <section id="contact" className="bg-neutral-950 py-12 px-6 md:px-24">
        <h2 className="text-2xl font-bold mb-6 text-center">Tell Us What You Need</h2>
        <form className="max-w-xl mx-auto space-y-4">
          <input type="text" placeholder="Your Name" className="w-full border border-gray-700 bg-neutral-900 text-white p-3 rounded-lg" required />
          <input type="email" placeholder="Your Email" className="w-full border border-gray-700 bg-neutral-900 text-white p-3 rounded-lg" required />
          <select className="w-full border border-gray-700 bg-neutral-900 text-white p-3 rounded-lg" required>
            <option value="">Select Service</option>
            <option value="social">Social Media Services</option>
            <option value="video">Video Production</option>
            <option value="photo">Photography</option>
          </select>
          <select className="w-full border border-gray-700 bg-neutral-900 text-white p-3 rounded-lg" required>
            <option value="">Select Budget</option>
            <option value="<500">Under $500</option>
            <option value="500-1000">$500 - $1,000</option>
            <option value=">1000">Over $1,000</option>
          </select>
          <textarea placeholder="Tell us more..." className="w-full border border-gray-700 bg-neutral-900 text-white p-3 rounded-lg" rows="4"></textarea>
          <Button type="submit" className="w-full py-3 text-lg bg-white text-black hover:bg-gray-200">Submit</Button>
        </form>
      </section>
    </div>
  );
}
